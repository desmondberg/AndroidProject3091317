package com.griffith.models

//a journal entry
data class JournalItem(
    val title: String,
    val description: String,
    val journeyType: String
)
